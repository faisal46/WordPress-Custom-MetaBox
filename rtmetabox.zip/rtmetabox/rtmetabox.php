<?php
/*
Plugin Name: RT Metabox
Plugin URI: www.rajtechbd.com
Description: WordPress Post Custom MetaBox.
Version: 1.0
Author: RajTech
Author URI: www.faisal.rajtechbd.com
License: GPLv2 or later
Text Domain: rtmetabox
Domain Path: /langusges/
*/
class RTMetabox{
    function __construct(){
        add_action( 'plugins_loaded', array($this, 'rtmb_load_textdomain') );
        add_action( 'admin_menu', array($this, 'rtmb_add_metabox') );
        add_action( 'save_post', array($this, 'rtmb_save_metabox') );
        add_action( 'admin_enqueue_scripts', array( $this, 'load_admin_assets' ) );
    }

    function rtmb_load_textdomain(){
        load_plugin_textdomain( 'rtmetabox', false, plugin_dir_url(__FILE__)."/languages" );
    }

    function load_admin_assets( $screen ){
            wp_enqueue_style( 'rtmb-admin-style-css', plugin_dir_url(__FILE__)."admin/css/rtmb-admin-style.css", null, time() );
            wp_enqueue_script( 'rtmb-admin-js', plugin_dir_url(__FILE__)."admin/js/rtmb-admin.js", array('jquery'),"1.0",true );
    }

    function rtmb_add_metabox(){

        add_meta_box(
            'rtmb_location',                 // Unique ID
            __( 'Location Info', 'rtmetabox' ),      // Box title
            array($this, 'rtmb_display_metabox'),
            array( 'post', 'page' )// Post type
        );

    }

    function rtmb_display_metabox( $post ){

        $location = get_post_meta( $post->ID, 'rtmb_location', true );
        $country = get_post_meta( $post->ID, 'rtmb_country', true );
        $favorite = get_post_meta( $post->ID, 'rtmb_favorite', true );
        $checked = $favorite == 1 ? 'checked' : '';
        $save_colors = get_post_meta( $post->ID, 'rtmb_color', true );
        $save_colors_radio = get_post_meta( $post->ID, 'rtmb_color_radio', true );
        $rtmb_dropdown_select = get_post_meta( $post->ID, 'rtmb_dropdown_select', true );

        $label_location = __( 'Location', 'rtmetabox' );
        $label_country = __( 'Country', 'rtmetabox' );
        $label_favorite = __( 'Favorite', 'rtmetabox' );
        $label_colors = __( 'Colors', 'rtmetabox' );
        $colors = array( 'red', 'white', 'green', 'yellow', 'orange', 'blue', 'black' );

        wp_nonce_field( 'rt_nonce_action', 'rt_nonce_name_field' );

        $metabox_html = <<<EOD
       <div class="rtmb_container">
          <label for="rtmb_location">{$label_location}:</label>
          <input type="text" id="rtmb_location" name="rtmb_location" value="{$location}" />
          <br><br/>
          <label for="rtmb_country">{$label_country}:</label>
          <input type="text" id="rtmb_country" name="rtmb_country" value="{$country}" />
       </div>
       <div class="rtmb_container">
          <label for="rtmb_favorite">{$label_favorite}:</label>
          <input type="checkbox" id="rtmb_favorite" name="rtmb_favorite" value="1" {$checked}/>
       </div>
     
       <div class="rtmb_container">
          <label>{$label_colors}:</label>
EOD;
        $save_colors = is_array( $save_colors ) ? $save_colors : array();
        foreach ( $colors as $color ){
            $_color = ucwords( $color );
            $checked = in_array( $color, $save_colors ) ? 'checked' : '';
            $metabox_html .= <<<EOD
           <label for="rtmb_color_{$color}">{$_color}:</label>
           <input type="checkbox" id="rtmb_color_{$color}" name="rtmb_color[]" value="{$color}" {$checked}/>
EOD;

        }
        $metabox_html .= "</div>";

        $metabox_html .= <<<EOD
<div class="rtmb_container">
          <label>{$label_colors}:</label>
EOD;
        foreach ( $colors as $color ){
            $_color = ucwords( $color );
            $checked = ( $color == $save_colors_radio ) ? "checked='checked'" : '';
            $metabox_html .= <<<EOD
           <label for="rtmb_color_radio{$color}">{$_color}:</label>
           <input type="radio" id="rtmb_color_radio{$color}" name="rtmb_color_radio" value="{$color}" {$checked}/>
EOD;

        }
        $metabox_html .= "</div>";
        /*
         * Design date field
         * */
//        $metabox_html .= <<<EOD
//<div class="rtmb_container">
//EOD;
//            $metabox_html .= <<<EOD
//           <label for="rtmb_date">Date:</label>
//           <input type="date" id="rtmb_date" name="rtmb_color_radio" />
//EOD;
//        $metabox_html .= "</div>";

        /*
         * Select dropdown select field data
         * */
        $metabox_html .= <<<EOD
<div class="rtmb_container">
EOD;
        $dropdown_html =  "<option value='0'>".__( 'Select a color', 'rtmetabox' )."</option>";
        foreach ( $colors as $color ){
            $selected = '';
            if( $color == $rtmb_dropdown_select ){
                $selected = 'selected';
            }
            $_color = ucwords( $color );
            $dropdown_html .= sprintf( '<option %s value="%s">%s</option>', $selected, $color, $_color );
        }
            $metabox_html .= <<<EOD
<label for="rtmb_dropdown_select">{$label_colors}</label>
<select name="rtmb_dropdown_select" id="rtmb_dropdown_select">
  {$dropdown_html}
</select>
EOD;
        $metabox_html .= "</div>";


        echo $metabox_html;

    }

    private function rt_nonce_secure( $nonce_field, $nonce_action, $post_id ){

        $rt_nonce = isset( $_POST[$nonce_field] )?$_POST[$nonce_field]:'';
        if( $rt_nonce == '' ){
            return false;
        }
        if( !wp_verify_nonce( $rt_nonce, $nonce_action ) ){
            return false;
        }
        if( !current_user_can( 'edit_post', $post_id ) ){
            return false;
        }
        if( wp_is_post_autosave( $post_id ) ){
            return false;
        }
        if( wp_is_post_revision( $post_id ) ){
            return false;
        }
        return true;

    }

    function rtmb_save_metabox( $post_id ){

        if( !$this->rt_nonce_secure( 'rt_nonce_name_field', 'rt_nonce_action', $post_id ) ){
            return $post_id;
        }

        $location = isset( $_POST['rtmb_location'] ) ? $_POST['rtmb_location'] : '';
        $country = isset( $_POST['rtmb_country'] ) ? $_POST['rtmb_country'] : '';
        $favorite = isset( $_POST['rtmb_favorite'] ) ? $_POST['rtmb_favorite'] : '';
        $colors = isset( $_POST['rtmb_color'] ) ? $_POST['rtmb_color'] : array();
        $colors_radio = isset( $_POST['rtmb_color_radio'] ) ? $_POST['rtmb_color_radio'] : '';
        $rtmb_dropdown_select = isset( $_POST['rtmb_dropdown_select'] ) ? $_POST['rtmb_dropdown_select'] : '';

//        if( $location == '' || $country == '' ){
//            return $post_id;
//        }

        $location = sanitize_text_field( $location );
        $country = sanitize_text_field( $country );

        update_post_meta( $post_id, 'rtmb_location', $location );
        update_post_meta( $post_id, 'rtmb_country', $country );
        update_post_meta( $post_id, 'rtmb_favorite', $favorite );
        update_post_meta( $post_id, 'rtmb_color', $colors );
        update_post_meta( $post_id, 'rtmb_color_radio', $colors_radio );
        update_post_meta( $post_id, 'rtmb_dropdown_select', $rtmb_dropdown_select );

    }
}
new RTMetabox();