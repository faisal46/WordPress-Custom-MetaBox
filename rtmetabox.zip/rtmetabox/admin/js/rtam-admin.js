;(function($) {
    $(document).ready(function() {
     alert('Admin script');
    });
})(jQuery);